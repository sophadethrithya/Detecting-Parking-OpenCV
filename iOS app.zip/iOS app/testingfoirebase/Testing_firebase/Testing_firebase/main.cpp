#include <iostream>
#include "firebase/app.h"
#include "firebase/database.h"
using namespace std;

int main(){
    firebase::AppOptions secondary_app_options;
    secondary_app_options.set_api_key("AIzaSyDwDvkOBpnLY7GB22axtQc2xnLnJgQAVyU");
    secondary_app_options.set_app_id("1:231802870701:ios:0382d55beb9c8a80");
    secondary_app_options.set_project_id("parking-233cc");
    firebase::App* secondary_app = firebase::App::Create(secondary_app_options, "Secondary");
     firebase::database::Database* secondary_database = firebase::database::Database::GetInstance(secondary_app);
    return 0;
}
