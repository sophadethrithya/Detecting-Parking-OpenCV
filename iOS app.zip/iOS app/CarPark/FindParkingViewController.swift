//
//  FindParkingViewController.swift
//  CarPark
//
//  Created by Sam on 7/28/18.
//  Copyright © 2018 Sam. All rights reserved.
//

import UIKit
import Firebase

class FindParkingViewController: UIViewController {
    
    //Label to change color
    @IBOutlet var allLabel: [UILabel]!
    
    
    override func viewDidLoad() {
//        super.viewDidLoad()
        
        initializeBackgroundColor()
        
        
//        allLabel[1].backgroundColor = UIColor.green
//        FirebaseApp.configure()
//        var ref: DatabaseReference!
//
//        ref = Database.database().reference()
//        ref.child("parking1").child("space-1:").setValue(1)
//        ref.child("parking1").child("space-1").observeSingleEvent(of: .value) { (snapshot) in
//            let value = snapshot.value as! Int
//            if value == 1
//            {
//                print("I have access the value")
//            }
//        }
//        labelnumberone.backgroundColor = UIColor.red
        // Do any additional setup after loading the view.
    }
    @IBAction func updateButton(_ sender: UIButton) {

        var ref: DatabaseReference!
        ref = Database.database().reference()

        for i in 0...16 {
            ref.child("parking1").child("space-\(i)").observeSingleEvent(of: .value) { (snapshot) in
                let value = snapshot.value as! Bool
                if value == false
                {
                    self.allLabel[i].backgroundColor = UIColor.red
                }
                if value == true
                {
                    self.allLabel[i].backgroundColor = UIColor.green
                }
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func LogOutPressed(_ sender: Any) {
        do {
           try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        }
        catch {
            print("error, there was a problem signing out")
        }
    }
    func initializeBackgroundColor(){
    
        var ref: DatabaseReference!
        ref = Database.database().reference()
        for i in 0...16{
            ref.child("parking1").child("space-\(i)").observeSingleEvent(of: .value) { (snapshot) in
                let value = snapshot.value as! Bool
                if value == false
                {
                    self.allLabel[i].backgroundColor = UIColor.red
                }
                if value == true
                {
                    self.allLabel[i].backgroundColor = UIColor.green
                }
            }
        }
        
    }
    

}
