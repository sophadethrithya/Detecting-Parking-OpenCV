//
//  ViewController.swift
//  CarPark
//
//  Created by Sam on 7/8/18.
//  Copyright © 2018 Sam. All rights reserved.
//

import UIKit
import Firebase

class FindViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func FindParkingPressed(_ sender: Any) {
        performSegue(withIdentifier: "goToFindParkingScreen", sender: self)
    }
    
    @IBAction func FindMyCarPressed(_ sender: Any) {
        performSegue(withIdentifier: "goToFindMyCarScreen", sender: self)
    }
    
}
        
        
        


